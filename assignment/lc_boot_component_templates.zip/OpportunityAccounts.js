$(function(){
	window.Opportunity = {
		Models:{},
		Collections:{},
		Views:{},
		Helpers:{},
		Templates:{},
		Routes:{},
		Events:{}
	};

	Opportunity.Events.Pagination = _.extend({}, Backbone.Events);

	Opportunity.Routes.Static_Routes = {
		GoToList_URL: null
	};

	Opportunity.Templates.OpportunityTemplate = function(id){
		return _.template($("#" + id).html());
	};

	Opportunity.Templates.OpportunityCollectionTemplate = function(options) {
		return _.template($("#" + options.id).html(), {collection : options.list});
	};
	Opportunity.Helpers.AddComma = function(param){
		var parts = param.toString().split(".");
		parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		return parts.join(".");
	};
	Opportunity.Helpers.LockDownAccount = function(item){
		var _i = item;
		return $(function(_n){
			return _n;
		}(_i));
	};

	Opportunity.Models.Custom_Filter = Backbone.Model.extend({
		defaults:{
			field_type: null,
			regular_expression: null,
			expression: null,
			callback: null
		},
		initialize: function(){
			this.on("change", function(model){
				this.get("callback")(model.toJSON());}, this);
		}
	});


	Opportunity.Models.OppReview = Backbone.Model.extend({
		defaults:{
			type:'Opportunity',
			AccountId: null,
			Amount: null,
			TotalOpportunityQuantity: null,
			CloseDate: null,
			CreatedDate: null,
			OpportunityAge: null,
			DaysInStage: null,
			ChangesToClose: null,
			Id: null,
			IsClosed: null,
			IsWon: null,
			Name: null,
			OwnerId: null,
			Owner:null,
			Probability: null,
			StageName: null,
			Type: null,
			AccountName: null,
			AXIOM_BASE__ChangesToCloseDate__c:null
		},
		initialize:function(){
			var oneDay = 24*60*60*1000;
			var isClosed = this.get("IsClosed");
			var age = this.get("AXIOMOMD__Age__c");
			var closeDate = new Date(this.get("CloseDate"));
			var createdDate = new Date(this.get("CreatedDate"));
			var lastModifiedDate = new Date(this.get("LastModifiedDate"));
			var TotalOpportunityQuantity= 0;
			if(this.get("TotalOpportunityQuantity")){
				TotalOpportunityQuantity= this.get("TotalOpportunityQuantity").toFixed(0);
			}
			var amount= 0;
			if(this.get("Amount")){
				amount= this.get("Amount").toFixed(0);
			}
			
			var accName = '';
			if(this.get("Account")){
				accName = this.get("Account").Name;
			}
			this.set({  AccountName: accName,
						Amount     : Opportunity.Helpers.AddComma(amount),
						TotalOpportunityQuantity     : Opportunity.Helpers.AddComma(TotalOpportunityQuantity),
						Probability: this.get("AXIOM_BASE__Probability_of_Win__c") + "%", 
						CloseDate  : new Date(closeDate).format('mmm dd, yyyy'),
						DaysInStage:  Math.round(this.get("AXIOM_BASE__Days_In_Stage__c") ? this.get("AXIOM_BASE__Days_In_Stage__c") : 0),
						OpportunityAge:  age ? age : isClosed ? Math.round((closeDate - createdDate)/oneDay) : Math.round((new Date().getTime() - createdDate)/oneDay)
					});
		}
	});

	Opportunity.Models.OpportunityGoToList = Backbone.Model.extend({
		defaults: {
			link: null,
			more: null,
			few: null,
			no_more: true,
			no_few: false,
			no_data: false,
			object_name:null,
			perPage: null,
			currentPage: 1,
			size: null,
			pageOutput:null,
			section_type:null
		},
		initialize: function(){

		}
	});

	Opportunity.Models.PageChange = Backbone.Model.extend({
		defaults:{
			current_page: null,
			per_page: null,
			page_size: null,
			total_records: null,
			sort_filter: null,
			search_1: null,
			search_2: null
		},
		initialize: function(){
		}
	});      //For arrows Next Prev

	Opportunity.Views.PageChange = Backbone.View.extend({
		 initialize:function(){
			 this.model.on('change',this.render, this);
		 },
		 render:function() {
			this.$el.html(ALCTemplates.Paging(this.model.toJSON()));
			return this;
		 },
		 events: {
			"click #next" :"nextPage",
			"click #prev" :"prevPage"
		 },
		 prevPage: function(evt){
			if (this.model.get("current_page") > 1) {
				var _current = this.model.get("current_page") - 1;
				var sort_filter = this.model.get("sort_filter");
				var search_1 = this.model.get("search_1");
				var search_2 = this.model.get("search_2");
				getRelatedList(_current, sort_filter, search_1, search_2);
				this.model.set({current_page:_current});
				//window.location.hash = 'page/' + _current;
			} 
		 },
		nextPage: function(evt){
			if(this.model.get("current_page")*this.model.get("per_page") < this.model.get("total_records")) {
				var _current = this.model.get("current_page") + 1;
				var sort_filter = this.model.get("sort_filter");
				var search_1 = this.model.get("search_1");
				var search_2 = this.model.get("search_2");
				getRelatedList(_current, sort_filter, search_1, search_2);
				this.model.set({current_page:_current});
				//window.location.hash = 'page/' + _current;
			}
		}
	});
	//View for arrows Next Prev

	Opportunity.Views.OppReview = Backbone.View.extend({
		tagName: 'tr',
		className:'component-body-item component-body-item-content',
		model:Opportunity.Models.OppReview,
		initialize:function(){

		},
		render:function(){
			this.$el.html(ALCTemplates.OpportunityAccountTemplate(this.model.toJSON()));
			return this;
		}
	});         //For one model

	Opportunity.Views.OppsReview = Backbone.View.extend({
		el:"#opportunityListSectionId",
		initialize:function(){
			this.collection.on("add", this.addOpportunity, this);
			Opportunity.Events.Pagination.on("pagination:showMore", this.showMore, this);
			Opportunity.Events.Pagination.on("pagination:showFew", this.showFew, this);
		},
		render:function(number){
			_.each(this.collection.goToPage(number, 1), this.addOpportunity, this);
			return this;
		},
		addOpportunity: function(opportunityModel){
			var _view = new Opportunity.Views.OppReview({model : opportunityModel});
			this.$el.append(_view.render().el);
		},
		showMore: function(number){
			this.$el.html('');
			this.render(number);
		},
		showFew: function(number){
			this.$el.html('');
			this.render(number);
		}
	});       //For collection

	Opportunity.Views.OpportunityPagination = Backbone.View.extend({
		initialize: function(){
			Opportunity.Events.Pagination.on("pagination:show", this.render, this);
		},
		render: function(){
			this.$el.html('');
			_.each(this.collection.goToPage(PageConfig.OpportunityPagination.perPage, PageConfig.OpportunityPagination.currentPage),this.addOne, this);
			return this;
		},
		addOne: function(model){
			var _v = new Opportunity.Views.OppReview({model: model});
			this.$el.append(_v.render().el);
		}
	});  //Pagination View with Next Prev

	Opportunity.Views.OpportunityGoToList = Backbone.View.extend({
			initialize: function() {
				this.model.on("change", this.render, this);
				this.model.set({no_data: this.model.get("perPage") >= this.model.get("size")});
			},
			render:function() {
			   this.$el.html(ALCTemplates.GoToListTemplate(this.model.toJSON()));
			   return this;
			},
			events: {
				"click #goto-Opportunities": "goToList",
				"click #more-Opportunities": "showMore",
				"click #few-Opportunities": "showFew"
			},
			goToList: function() {
				 var url = Opportunity.Routes.Static_Routes.GoToList_URL + "&show=" + this.model.get("object_name");
				 var width = 1000, height = 460;
				 //width = window.innerWidth * 0.7;
				 //height = window.innerHeight * 0.8;
				 var list = window.open(url, "_blank", "width="+width+",height="+height+",scrollbars=1,resizable");
				 list.focus();
			},
			showMore: function() {
				var output = this.model.get("pageOutput") + this.model.get("perPage");
				_m = output;
				_nf = output > this.model.get("perPage");
				_nm = output < this.model.get("size");

				this.model.set({
						more: _m,
						no_few: _nf,
						no_more: _nm,
						pageOutput:output
					}
				);
				this.simulateEvent(true);
			},
			showFew: function() {
				var output = this.model.get("pageOutput") - this.model.get("perPage");
				_m = output;
				_nf = output > this.model.get("perPage");
				_nm = output < this.model.get("size");
				this.model.set({
						more: _m,
						no_few: _nf,
						no_more: _nm,
						pageOutput:output
					}
				);
				this.simulateEvent(false);
			},
			simulateEvent: function(mf){
				  if(mf === true) { Opportunity.Events.Pagination.trigger("pagination:showMore", this.model.get("more")); }
				  else { Opportunity.Events.Pagination.trigger("pagination:showFew", this.model.get("more")); }
			}
	});

	Opportunity.Views.AddOpportunity = Backbone.View.extend({
		el: "#addOpportunity",
		events:{
			"submit": "submit"
		},
		initialize:function(){
		   console.log(this.el.innerHTML);
		},
		submit:function(e){
			e.preventDefault();
			var newOpportunity = $(e.currentTarget).find("input[type=text]").val();
			var item = new Opportunity.Models.OppReview({Name: newOpportunity});
			this.collection.add(item);
		}
	}); //For add to collection   FOR TEST

	Opportunity.Collections.OppReview = Backbone.Collection.extend({
		model: Opportunity.Models.OppReview,
		goToPage: function(perPage, page){
			page = page - 1;
			var collection = this;
			collection = _(collection.rest(perPage * page));
			collection = _(collection.first(perPage));
			return collection.map(function(model){ return model; });
		},
		goToFew: function(perPage, page){
			page = page - 1;
			var collection = this;
			collection = _(collection.rest(perPage * page));
			return collection.map(function(model){ return model; });
		}
	});

	Opportunity.Routes.OpportunityRoutes = Backbone.Router.extend({
		routes:{
			''    : 'index',
			'page/:number': 'pagination'
		},
		pagination: function(number){
			Opportunity.Events.Pagination.trigger("pagination:show", number);
		}
	});   // FOR TEST

//-------------------------Account SECTION-------------------------------------
//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

	Opportunity.Models.AccountReview = Backbone.Model.extend({
		defaults:{
			type:'Account',
			AnnualRevenue: 0,
			BillingCity: null,
			BillingCountry: null,
			CreatedById: null,
			CreatedDate: 0,
			Id: null,
			IsDeleted: null,
			LastModifiedById: null,
			LastModifiedDate: 0,
			Name: null,
			NumberOfEmployees: 0,
			Owner: {},
			OwnerId: null,
			AXIOM_APM__AccountHealthScore__c: null,
			AXIOM_APM__AvgWinProbability__c: null,
			AXIOM_APM__TotalPipeline__c: null,
			AXIOM_APM__PrimaryAccount__r: {}
		}
	});

	Opportunity.Views.AccountReview = Opportunity.Views.OppsReview.extend({
		el: '#accountReview',
		initialize:function(){
			Opportunity.Events.Pagination.on("account:showMore", this.showMore, this);
			Opportunity.Events.Pagination.on("account:showFew", this.showFew, this);
			if(_.isUndefined(this.collection)) {
				$('.accreview').remove();
				return;
			}
		}
	});

	Opportunity.Views.AccountGoToList = Opportunity.Views.OpportunityGoToList.extend({
		events:{
			"click #goto-Accounts": "goToList",
			"click #more-Accounts": "showMore",
			"click #few-Accounts": "showFew"
		},
		simulateEvent:function(mf){
			if(mf === true) { Opportunity.Events.Pagination.trigger("account:showMore", this.model.get("more")); }
			else { Opportunity.Events.Pagination.trigger("account:showFew", this.model.get("more")); }
		}
	});

	Opportunity.Collections.AccountReview =   Opportunity.Collections.OppReview.extend({
		model: Opportunity.Models.AccountReview
	});

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
//--------------------END OF --- //Account SECTION-----------------------------


/*******************************************************************************
*-Assignment section
*******************************************************************************/
window.Assignment = {
		Models: {}, Views: {},  Collections: {}
	};

	$.fn.serializeObject = function(){
		var o = {};
		var a = this.serializeArray();
		$.each(a, function(){
			if(o[this.name] !== undefined) {
				if(!o[this.name].push) {
					o[this.name] = [o[this.name]];
				}
				o[this.name].push(this.value || '');
			} else {
				o[this.name] = this.value || '';
			}
		});
		return o;
	};

	Assignment.Models.AssignModel = Backbone.Model.extend({
		initialize: function(){
		   this.regExpDate = /^[0,1]?\d\/(([0-2]?\d)|([3][01]))\/((199\d)|([2-9]\d{3}))\s[0-2]?[0-9]:[0-5][0-9] (am|pm)?$/;
		   this.simpleTime = /^[0,1]?\d\/(([0-2]?\d)|([3][01]))\/((199\d)|([2-9]\d{3}))\s?$/;
		},
		defaults: {
			type:'Assignments',
			AXIOM_BASE__Description__c:null,
			AXIOM_BASE__Due_Date__c: null,
			AXIOM_BASE__Status__c: null,
			AXIOM_BASE__Type__c: null,
			AXIOM_BASE__User__c: null,
			AXIOM_BASE__Opportunity__c:null,
			AXIOM_BASE__Opportunity__r:null,
			AXIOM_BASE__User__c:null,
			AXIOM_BASE__User__r:null,
			AXIOM_BASE__Wizard_Usage_History_Item__c:null,
			CreatedDate: null,
			Id: null,
			Name: null,
			/*===event definition===*/
			Event_Start_Date: null,
			Event_End_Date: null,
			Assignment_Type: null
		},
		validate : function(attrs, options) {
			if (options.eventCheck) {
				if (this.regExpDate.test(attrs.Event_Start_Date) === false) { $(options.sd).effect("highlight","slow"); return "start date";}
				if (this.regExpDate.test(attrs.Event_End_Date) === false) { $(options.ed).effect("highlight","slow"); return "end date";}
				if (attrs.AXIOM_BASE__Description__c === '') { $(options.ds).effect("highlight","slow"); return "description missing";}
			} else {
				if(attrs.AXIOM_BASE__Description__c === '') { $(options.ds).effect("highlight","slow"); return "description missing";}
				if (this.simpleTime.test(attrs.AXIOM_BASE__Due_Date__c) === false) {  $(options.dd).effect("highlight","slow"); return "due date";}
			} 
		},
		formateDate : function(adate){
			if(adate instanceof Date) {
				return (adate.getMonth() + 1) + '/' + (adate.getDate()) + '/' + (adate.getFullYear());
			} 
			return "-";
		}
	});

	Assignment.Collections.AssignCollection = Opportunity.Collections.OppReview.extend({
		model: Assignment.Models.AssignModel
	});


	Assignment.Views.CreateAssignment = Backbone.View.extend({
		el:'#assignment-form-view',
		initialize: function(options) {
			this.saveAssignment = options.saveAssignment;
			this.seller = options.seller;
		},
		events: {
			"click #assignment-save"    : "renderInput",
			"click #assignment-cancel"  : "hideView"
		},
		render: function(attrs) {
		var assignDate = new Date();
		var dueDate = new Date(assignDate.setDate(assignDate.getDate() + 30));
		var nowDate = new Date();
		if(attrs.task) {
			this.model.set({
				AXIOM_BASE__Due_Date__c :   this.model.formateDate(dueDate),
				CreatedDate             :   this.model.formateDate(nowDate),
				AXIOM_BASE__Type__c     :   'Selling',
				AXIOM_BASE__User__c     :   this.seller,
				Assignment_Type         :   'Task'
			});
			this.$el.html(ALCTemplates.AssignmentTask(this.model.toJSON()));
			 $('.assignment-date-picker').datepicker();
		} else {
			this.model.set({
				Event_Start_Date        :   this.model.formateDate(dueDate),
				Event_End_Date          :   this.model.formateDate(dueDate),
				CreatedDate             :   this.model.formateDate(nowDate),
				AXIOM_BASE__Type__c     :   'Selling',
				AXIOM_BASE__User__c     :   this.seller,
				Assignment_Type         :   'Event'
			});
			this.$el.html(ALCTemplates.AssignmentEvent(this.model.toJSON()));
			$('.assignment-date-picker').datetimepicker({ timeFormat: "hh:mm tt" });
		}
			return this;
		},
		renderInput: function(vent) {
			vent.preventDefault();
				var form = this.$el.find('form');
				var sform = form.serializeObject();

			if(this.model.get('Assignment_Type') === 'Task') {

				this.model.set({ 
					AXIOM_BASE__Description__c  : sform['assignment-description'], 
					AXIOM_BASE__Due_Date__c     : sform['due-date'] 
				});

				 if(this.model.isValid({ ds: form.find("textarea"), dd: form.find("input[name=due-date]") })) {
					  this.saveAssignment(this.model.get('AXIOM_BASE__Description__c'), this.model.get('AXIOM_BASE__Due_Date__c'), null);
				}
			} else {
				  this.model.set({ 
							AXIOM_BASE__Description__c  : sform['assignment-description'], 
							Event_Start_Date            : sform['start-date'], 
							Event_End_Date              : sform['end-date']
						}, {eventCheck: true});
				if(this.model.isValid({ eventCheck : true, sd : form.find("input[name=start-date]"), 
														   ed : form.find("input[name=end-date]"), 
														   ds : form.find("textarea")
										})) {
					var sd = new Date(sform['start-date']); 
					var ed = new Date(sform['end-date']); 
					if(sd > ed) { $('.left.error').text('End date must be grater than Start date'); $('.left.error').effect("highlight","slow"); return; }
					sd = new Date(sd.setDate(sd.getDate() + 14)); 
					if(sd < ed) { $('.left.error').text('Days between start and end date must be maximum 14'); $('.left.error').effect("highlight","slow"); return; }
					
					$('.left.error').empty();
					this.hideView();
					$('.small-loader').css({ 'display' : 'inline' });

					this.saveAssignment(this.model.get('AXIOM_BASE__Description__c'), this.model.get('Event_Start_Date'), this.model.get('Event_End_Date'));
				}
			}

			form.trigger('reset');  
			this.model.set({
				AXIOM_BASE__Description__c : null,
				AXIOM_BASE__Due_Date__c : null,
				Event_Start_Date : null,
				Event_End_Date : null
			});
		},
		hideView: function(vent) {
			this.$el.css({ display: "none" });
		}
	});

	Assignment.Views.AssignmentView = Opportunity.Views.OppsReview.extend({
		el:'#assignment-view',
		initialize:function(){
			Opportunity.Events.Pagination.on("assignment:showMore", this.showMore, this);
			Opportunity.Events.Pagination.on("assignment:showFew", this.showFew, this);
			this.collection.on('add',function(){  },this);
		}
	});

	Assignment.Views.AssignmentGoToList = Opportunity.Views.OpportunityGoToList.extend({
		events:{
			"click #goto-Assignments"   : "goToList",
			"click #more-Assignments"   : "showMore",
			"click #few-Assignments"    : "showFew",
			"click #toggleAssignments"  : "togglesection"
		},
		simulateEvent:function(mf){
			if(mf === true) { Opportunity.Events.Pagination.trigger("assignment:showMore", this.model.get("more")); }
			else { Opportunity.Events.Pagination.trigger("assignment:showFew", this.model.get("more")); }
		},
		togglesection:function(vent){
			var target = $(vent.currentTarget);
				if(target.attr("data-completed") == "true") {
					target.attr("data-completed", false);
					target.text('Show Completed Assignments');
				} else {
					target.attr("data-completed", true);
					target.text('Hide Completed Assignments');
				}
			var pplcollect = $('#people-collection').val();
			var sellerid = $("#current-seller").attr("href").replace("/","");
			var ppsend = (pplcollect === "") ? sellerid : pplcollect;
			//implemets on page
			getLmsAssignment(ppsend, null, target.attr("data-completed"));
		}
	});

/****************************-End assignemnts**********************************/


	Opportunity.Views.Pagination = Backbone.View.extend({
		initialize:function(args){
			Opportunity.Events.Pagination.on("pagination:show", this.render, this);
			if(this.collection.apm_package_install) {
				if (this.collection.apm_package_install() === true) {$('.apm-package').remove();}
			}
			this.render();

		},
		render: function(number) {
			var template = ALCTemplates.Paginator({collection: this.collection.goToPage(this.model.get("per_page"), number)});
			this.$el.html(template);
			return this;
		}
	});
	 
}());
