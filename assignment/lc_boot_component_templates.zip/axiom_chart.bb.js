(function(){
	window.Chart = {
		Models:{},
		Views:{},
		Helpers:{},
		Collection:{},
		Callout:{
			Models:{},
			Views:{},
			Collection:{}
		}
	};
	//sales cycle template
	window.Chart.SalesCycle = function(){
		return {
				"chart": {
					"manageresize": "1",
					"origw": "350",
					"origh": "200",
					"bgalpha": "0",
					"bgcolor": "FFFFFF",
					"showborder": "0",
					"charttopmargin": "5",
					"chartbottommargin": "5",
					"gaugefillmix": "{dark-10},{light-70},{dark-10}",
					"gaugefillratio": "3",
					"pivotradius": "8",
					"gaugeouterradius": "120",
					"gaugeinnerradius": "70%",
					"gaugeoriginx": "175",
					"gaugeoriginy": "170",
					"trendvaluedistance": "5",
					"tickvaluedistance": "3",
					"managevalueoverlapping": "1",
					"autoaligntickvalues": "1",
					"formatNumberScale":"1",
					"decimalPrecision":"0",
					"showLimits": 0,
					"showTickValues":"0",
					//"basefontcolor": "FFFFFF",
					//"tooltipbgcolor": "AEC0CA",
					//"tooltipbordercolor": "FFFFFF",
					"baseFontSize":"12"
				},
				"colorrange": {
					"color": [
						{
							"minvalue": "0",
							"maxvalue": "100",
							"code": "8BBA00"
						},
						{
							"minvalue": "0",
							"maxvalue": "100",
							"code": "8BBA00"//F6BD0F
						},
						{
							"minvalue": "0",
							"maxvalue": "100",
							"code": "8BBA00"//FF654F
						}
					]
				},
				"trendpoints": {
					"point": [
						{
							"startvalue": -999999999,
							"endvalue": -999999999,
							"color": "E10000",
							"radius": "120",
							"innerradius": "5%",
							"alpha": "70"
						}
					]
				},
				"dials": {
					"dial": [
						{
							"value": "62",
							"rearextension": "10",
							"basewidth": "10"
						}
					]
				}
			};
		};
	//JSON TEMPLATES-----------------------------------------
	window.Chart.Json_template = function() {
		return {
			chart: {
				width:278,
				height:184,
				type: 'line',
				zoomType: null,
				resetZoomButton: {
					position: {
						x: 0,
						y: -300
					},
					theme: {
						display: 'none'
					}
				},
				showAxes:true,
				events:{
					redraw: function(event) {
					},
					load: function(event) {
						window.Chart.Helpers.Loaded++;
					}
				},

				renderTo:null,
				style: {
					fontFamily: '"Lucida Grande", "Lucida Sans Unicode", Verdana, Arial, Helvetica, sans-serif', // default font
					fontSize: '12px'
				}
			},
			colors: [   '#3366FF',    '#66CD00',    '#8bbc21',    '#910000',    '#1aadce',    '#492970',   '#f28f43',    '#77a1e5',    '#c42525',    '#a6c96a'],
			credits:{enabled:false},
			navigation: {
				buttonOptions: {
				enabled:false
				}
			},
			title: {
				enabled:false,
				text: null
			},
			xAxis: {
				//minRange: 7 * 24 * 3600 * 1000,
				type: 'datetime',
				dateTimeLabelFormats: { // don't display the dummy year
					day: '%e. %b',
					week: '%e. %b',
					month: '%b \'%y',
					year: '%Y'
				},
				events: {
					afterSetExtremes: function(event){
					if(sliderEnabled) {
							$("#scroller").dateRangeSlider("values", new Date(event.min), new Date(event.max));
					}
					}
				},
				labels: {
					x: 0,
					y: 20
				},
				endOnTick: false,
				showFirstLabel: true,
				startOnTick: false,
				showLastLabel: true,
				tickInterval: null
			},
			yAxis: {
				lineWidth: 1,
				tickWidth: 1,
				title: {
					enabled:false
				},
				labels: {
					formatter: function() {
					var absValue = Math.abs(this.value);
					if (absValue >= 1000) {
						absValue = (absValue / 1000) + 'K';
					} else
					if (absValue >= 1000000) {
						absValue = (absValue / 1000000) + 'M';
					}
					return this.chart.tooltip.options.valuePrefix+absValue+this.chart.tooltip.options.valueSuffix;
				}
				},
				min: 0
			},
			tooltip: {
				valueSuffix: '',
				valuePrefix: '',
				crosshairs: {
					dashStyle: 'dash'
				}
			},
			legend: {
				enabled: false
			},
			plotOptions: {
				series: {
					enabled: false,
					states:{
						hover:{
						enabled:true
					}},
					dataGrouping : {
						enabled: false,
						//groupPixelWidth: 100,
						units : [
							['day', [1]],
							['week', [1]],
							['month', [1]],
							['year', [1]]
						]
					}
				}
			},
			series: [
				{
					lineWidth: 1,
					shadow: false, 
					marker: { enabled: true,states: { hover: { lineWidth:1,radius:5 } }},
					name:null,
					data: null,
					tooltip: {
						valueDecimals: 0
					}
				},
				{ 
					type: 'line', 
					marker: { enabled: false }, 
					data:null, 
					name:null,
					enableMouseTracking: false,
					tooltip: {
						valueDecimals: 0
					}
				}
			]
			};
	};

	window.Chart.Json_angular = function() {
		return {
			"chart": {
				"lowerlimit": "0",
				"upperlimit": "100",
				"lowerLimitDisplay": "Bad",
				"upperLimitDisplay": "Good",
				"numbersuffix": "%",
				"showvalue":"0",
				"gaugeStartAngle":"225",
				"gaugeEndAngle":"-45",
				"manageResize":"1"
			},
			"colorrange": {
				"color": [
					{
						"minvalue": "0",
						"maxvalue": "40",
						"code": "FF654F"
					},
					{
						"minvalue": "40",
						"maxvalue": "70",
						"code": "F6BD0F"
					},
					{
						"minvalue": "70",
						"maxvalue": "100",
						"code": "8BBA00"
					}
				]
			},
			"annotations":{
					"groups":[
					{
						"id":"grp01",
						"items":
						[
							{
								"bold":"1",
								"color":"404040",
								"font":"Helvetica Neue, Helvetica, Arial, sans-serif",
								"fontSize":"11",
								"label":"Avg. Win Probability",
								"type":"text",
								"x":"65%",
								"y":"20%"
							},
							{
								"bold":"0",
								"color":"000000",
								"font":"Helvetica Neue, Helvetica, Arial, sans-serif",
								"fontSize":"20",
								"label":"0%",//dial value
								"type":"text",
								"x":"50%",
								"y":"50%"
							}
						]
					}
				]
			},
			"dials": {
				"dial": [
					{
						"value": null,
						"rearextension": "10",
						"basewidth": "10"
					}
				]
			},
			"styles": {
				"definition": [
				   
				],
				"application": [
				   
				]
			}
		};
		
	};

	window.Chart.Json_angular_gauge = function() {
		return {
	"chart": {
		"manageresize": "1",
		"origw": "350",
		"origh": "200",
		"bgalpha": "0",
		"bgcolor": "FFFFFF",
		"showborder": "0",
		"charttopmargin": "5",
		"chartbottommargin": "5",
		"gaugefillmix": "{dark-10},{light-70},{dark-10}",
		"gaugefillratio": "3",
		"pivotradius": "8",
		"gaugeouterradius": "120",
		"gaugeinnerradius": "70%",
		"gaugeoriginx": "175",
		"gaugeoriginy": "170",
		"trendvaluedistance": "5",
		"tickvaluedistance": "3",
		"managevalueoverlapping": "0",
		"autoaligntickvalues": "0",
		"formatNumberScale":"1",
		"decimalPrecision":"0",
		"showLimits": 0,
		"showTickValues":"0",
		"baseFontSize":"12"
	},
	"colorrange": {
		"color": [
			{
				"minvalue": "0%",
				"maxvalue": "45%",
				"code": "FF654F"
			},
			{
				"minvalue": "45%",
				"maxvalue": "80%",
				"code": "F6BD0F"
			},
			{
				"minvalue": "80%",
				"maxvalue": "100%",
				"code": "8BBA00"
			}
		]
	},
	"dials": {
		"dial": [
			{
				"value": "900000000",
				"rearextension": "10",
				"basewidth": "10"
			}
		]
	},
	"trendpoints": {
		"point": [
			{
				"startvalue": "20",
				"usemarker": "1",
				"markerradius": "8",
				"dashed": "1",
				"dashlen": "2",
				"dashgap": "2"
			}
		]
	}
};
	};

	window.Chart.Chart_Type = {
		Angular_URL: "js/AngularGauge.swf",    //test-test
		MsLine_URL: "js/MSLine.swf"
	};
	//HELPERS------------------------------------------------
	window.Chart.Helpers.Parser = function(request_data){
		var _result = [];
		for(var prop in request_data) {
			if (request_data.hasOwnProperty(prop)) {
				if("Name" in request_data[prop]) {
					_result.push({chart_name:request_data[prop].Name, chart_data:request_data[prop]});
				} else {
					_result.push({chart_name:prop, chart_data:request_data[prop]});
				}
			}
		}
		return _result;
	};
	window.Chart.Helpers.LabelsFormatter = function(maxVal,value) {
					var result = Math.abs(value);
					var absValue = Math.abs(maxVal);
					if (absValue >= 1000000) {
						result = (Math.abs(value)  / 1000000);
					} else
					if (absValue >= 1000) {
						result = (Math.abs(value) / 1000);
					}
					
					return Math.round(result);
				};
	window.Chart.Helpers.LegendFormatter = function(value) {
				var result = '';
				var absValue = Math.abs(value);
				if (absValue >= 1000000) {
					result = 'M';
				} else
				if (absValue >= 1000) {
					result = 'K';
				}
				
				return result;
			};
	window.Chart.Helpers.Loaded = 0;
	window.Chart.Helpers.GetArraySize  = function(obj) {
				var size = 0, key;
				for (key in obj) {
					if (obj.hasOwnProperty(key)) size++;
				}
				return size;
				};
	window.Chart.Helpers.ResizeCharts  = function() {
				for( var item in FusionCharts.items) {
					if(FusionCharts.items.hasOwnProperty(item)) {
						//if(item != 'myChartAvgWinProbId')
							FusionCharts(item).render();
					}
				}
				for(var i = 0; i<  Highcharts.charts.length;i++){
					Highcharts.charts[i].redraw();
				}
			};
	window.Chart.Helpers.isZoomScrollEnabled = true;

	Chart.Helpers.Month_Array = [
		"Jan","Feb","Mar","Apr",
		"May","Jun","Jul","Aug",
		"Sep","Oct","Nov","Dec"
	];

	window.Chart.Request = null;

	window.Chart.Template = function(id){
		return _.template($('#'+id).html());
	};

	window.Chart.Chart_template = function(chartID, data) {
	
	if(data.trendpoints){
		var chart = new FusionCharts( Chart.Chart_Type.Angular_URL, chartID + "_chart", "295", "165" );
		chart.showLegend = false;
		chart.dataFormat = "json";
		chart.setJSONData(data);
		chart.render(chartID);
	} else {
		new Highcharts.Chart(data);
	}
	};

	//MODELS---------------------------------------------
	Chart.Models.Core_Metric = Backbone.Model.extend({
		defaults: {
			chart_name:null,
			dial:null,
			chart_data:{},
			response:{}
		},
		initialize:function() {
			var _data = this.get("chart_data");
			var jsonTemplate = null;
			var subData = _data.Data;

			var seriesData = subData.Data;
				
				var json_template = Chart.Json_template();
				json_template.chart.renderTo = _data.Name;
				json_template.chart.zoomType = _data.zoomType ? _data.zoomType : null;
				json_template.plotOptions.series.dataGrouping.enabled = _data.zoomType ? true : false;
				json_template.series[0].name = _data.Name;
				json_template.series[0].data = seriesData;
				json_template.series[0].marker.enabled = seriesData.length > 2 ? false:true;
				if(_data.Name.toLowerCase() != 'sales cycle'){
					json_template.series[1].name = _data.Name;
					json_template.series[1].data = subData.RegressionData;    
					json_template.series[1].enableMouseTracking = true;
					json_template.series[1].marker.enabled = subData.RegressionData.length > 2 ? false:true;
				}

				/*if (subData.RegressionData && seriesData) {
					var tos = subData.RegressionData.length > seriesData.length ? subData.RegressionData.length : seriesData.length;
					console.log(tos);
					json_template.xAxis.tickInterval = Math.round(tos/5);
				}*/
		   
				if(subData.Format.indexOf("*") != -1) {
					/*json_template.tooltip.valuePrefix = subData.Format;
					json_template.yAxis.labels.formatterPrefix = subData.Format;*/
					
				} else if (subData.Format.indexOf("%") != -1) {
					json_template.tooltip.valueSuffix = subData.Format;
					json_template.yAxis.labels.formatterSuffix = subData.Format;
				}
				
				this.set({response: json_template});
			
		}
	});
	window.Chart.Helpers.AddComma = function(param){
		var parts = param.toString().split(".");
		parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		return parts.join(".");
	};
	Chart.Models.Angular_vs_Chart =  Chart.Models.Core_Metric.extend({
		initialize:function(){
			var _data = this.get("chart_data");
			var jsonTemplate = null;
			var subData = _data.Data;
			if(!subData.Data) {
				jsonTemplate = Chart.Json_angular_gauge();
				//jsonTemplate = Chart.SalesCycle();
				var dial = subData.Dial;
				var ryD =subData.RedYellowDivider;
				var ygD =subData.YellowGreenDivider;
				var trendpoint = subData.Trendpoint;
				
				var max = dial;
				if(ryD>max){max=ryD;}
				if(ygD>max){max=ygD;}
				max = max+max*0.2
				
				jsonTemplate.trendpoints.point[0].startvalue = trendpoint;
				jsonTemplate.dials.dial[0].value = dial;
				
				
				jsonTemplate.colorrange.color[0].maxvalue = ryD;
				jsonTemplate.colorrange.color[1].minvalue = ryD;
				jsonTemplate.colorrange.color[1].maxvalue = ygD;
				jsonTemplate.colorrange.color[2].minvalue = ygD;
				
				
				var format = subData.Format;
					switch (format) {
						case '*': {
							//jsonTemplate.chart.numberPrefix = format;
							jsonTemplate.colorrange.color[2].maxvalue = max;
							this.set({dial: window.Chart.Helpers.AddComma(dial.toFixed(0))+format });
						} break;
						case '%':  {
							jsonTemplate.colorrange.color[2].maxvalue = 100;
							jsonTemplate.chart.numberSuffix = format;
							this.set({dial: dial + format });
						} break;
						default:{
							jsonTemplate = null;
							jsonTemplate = Chart.SalesCycle();
							jsonTemplate.trendpoints.point[0].startvalue = 100;
							jsonTemplate.dials.dial[0].value = dial;
							if(dial > 100){
								jsonTemplate.colorrange.color[2].maxvalue = dial+dial*0.1;
							}
							 if(dial < 50 ){
								jsonTemplate.colorrange.color[0].maxvalue = jsonTemplate.colorrange.color[0].maxvalue*0.5;
								jsonTemplate.colorrange.color[1].minvalue = jsonTemplate.colorrange.color[1].minvalue*0.5;
								jsonTemplate.colorrange.color[1].maxvalue = jsonTemplate.colorrange.color[1].maxvalue*0.5;
								jsonTemplate.colorrange.color[2].minvalue = jsonTemplate.colorrange.color[2].minvalue*0.5;
								jsonTemplate.colorrange.color[2].maxvalue = jsonTemplate.colorrange.color[2].maxvalue*0.5;
							 }
							/*//0
							jsonTemplate.colorrange.color[0].code = "8BBA00"; // green
							jsonTemplate.colorrange.color[0].maxvalue = ygD;
							//yellow
							jsonTemplate.colorrange.color[1].minvalue = ygD;
							jsonTemplate.colorrange.color[1].maxvalue = max-ryD;
							//red
							jsonTemplate.colorrange.color[2].minvalue = max-ryD;
							jsonTemplate.colorrange.color[2].maxvalue = max;
							jsonTemplate.colorrange.color[2].code = "FF654F";*/
							this.set({dial: dial + ' Days'});
						} break;
					}
				this.set({response: jsonTemplate});
			} else {
				var seriesData = subData.Data;
				
				var json_template = Chart.Json_template();
				
				json_template.chart.renderTo = _data.Name;
				json_template.series[0].name = _data.Name;
				json_template.series[0].data = seriesData;
				json_template.series[1].name = _data.Name;
				json_template.series[1].data = subData.RegressionData;
				json_template.series[0].marker.enabled = seriesData.length > 2 ? false:true;
				json_template.series[1].marker.enabled = false;
				if(seriesData.length !== 0){
					this.set({dial: Math.round(seriesData[seriesData.length-1][1])});
				}
				
				//json_template.chart.height = 180;
			
				
				if(subData.Format.indexOf("*") != -1) {
					/*json_template.tooltip.valuePrefix = subData.Format;
					json_template.yAxis.labels.formatterPrefix = subData.Format;*/
				} else if (subData.Format.indexOf("%") != -1) {
					json_template.tooltip.valueSuffix = subData.Format;
					json_template.yAxis.labels.formatterSuffix = subData.Format;
				}
				
				this.set({response: json_template});
			}


		}
	});

	Chart.Models.Month_Model = Backbone.Model.extend({
		defaults:{
			month_name:null,
			month_sales:null
		}
	});

	Chart.Models.Angular_Gauge = Backbone.Model.extend({
		 defaults:{
			 caption: null,
			 response:null
		 },
		initialize:function(){
			var j_data = Chart.Json_angular();
			j_data.annotations.groups[0].items[1].label = this.get("caption")+"%";
			j_data.dials.dial[0].value = this.get("caption");
			this.set({response: j_data});
		},
		render_AngularGauge: function(){
			var myChartAvgWinProb = new FusionCharts( Chart.Chart_Type.Angular_URL, "myChartAvgWinProbId", "445", "105", "0" );      //{!URLFOR($Resource.FusionChart, 'Charts/AngularGauge.swf')}
			myChartAvgWinProb.setJSONData(this.get("response"));
			myChartAvgWinProb.render("avgWinProbId");
		}
	});

	//VIEWS------------------------------------------------
	Chart.Views.Core_Metric = Backbone.View.extend({
		tagName:"div",
		className:"chart-container left",
		initialize:function(){
			this.render();
		},
		render:function(){
			this.$el.html(ALCTemplates.ChartTemplate(this.model.toJSON()));
			return this;
		}
	});
	Chart.Views.CurrentPeriodView = Backbone.View.extend({
		tagName:"div",
		className:"chart-container left chart-container-currentPeriod",
		initialize:function(){
			this.render();
		}, 
		render:function(){
			this.$el.html(ALCTemplates.CurrentPeriodTemplate(this.model.toJSON()));
			return this;
		}
	});

	Chart.Views.Core_Metrics = Backbone.View.extend({
		tagName:"div",
		className:"component-body",
		initialize:function(){

		},
		render:function(){
			this.collection.each(function(core_metric){
				var _v = new Chart.Views.Core_Metric({model: core_metric});
				this.$el.append(_v.render().el);
			},this);
			return this;
		},
		dispose: function(){
			this.collection.each(function(model){
				//FusionCharts(model.get("chart_name")+'_chart').dispose();
			},this);
		}
	});
	var chartCPCount = 0;
	Chart.Views.CurrentPeriodViews = Backbone.View.extend({
		tagName:"div",
		className:"component-body",
		initialize:function(){

		},
		render:function(){
			this.collection.each(function(core_metric){
				var _v = new Chart.Views.CurrentPeriodView({model: core_metric});
				this.$el.append(_v.render().el);
				chartCPCount++;
				if (chartCPCount == 3) {
					this.$el.append('<div class="clear"></div>');
					chartCPCount = 0;
				}
			},this);
			return this;
		},
		dispose: function(){
		for( var item in FusionCharts.items) {
			if(FusionCharts.items.hasOwnProperty(item)) {
				if(item != 'myChartAvgWinProbId') {
					FusionCharts(item).dispose();
				}
			}
		}
	}
	});

	//COLLECTIONS---------------------------------------------
	Chart.Collection.Core_Metric = Backbone.Collection.extend({
		model: Chart.Models.Core_Metric
	});

	Chart.Collection.Angular_vs_Chart = Backbone.Collection.extend({
		model: Chart.Models.Angular_vs_Chart
	});

	Chart.Collection.Month_Collection = Backbone.Collection.extend({
		model:Chart.Models.Month_Model,
		comparator:function(modelF, modelL){
			try {
				var param1 = new Date(Date.parse(modelF.get("month_name")));
				var param2 = new Date(Date.parse(modelL.get("month_name")));
				return param1 - param2;
			}catch(exc) {
				return 0;
			}
		}
	});

	Chart.Callout.Collection.ChartCollection = {};

	Chart.Callout.Views.ChartView = {};
}());