$(function(){
	window.Assignment = {
		Models: {},	Views: {},	Collections: {}
	};

	Assignment.Models.AssignModel = Backbone.Model.extend({
		defaults: {
			description_url:null,
			description: null,
			due_Date: null,
			create_Date: null,
			type: null, /* - 'Selling'/ 'Development' */
			opportunityId: null,
			opportunity: null,
			assignee: null,
			assigneeId: null,
		}
	});

	Assignment.Collections.AssignCollection = Backbone.Collection.extend({
		model: Assignment.Models.AssignModel
	});

	Assignment.Views.AssignView = Backbone.View.extend({
		el: '#assignment-view',
		template: function(options) {
			return ALCTemplates.AssignmentsTemplate({ list: options.collection });
		},
		initialize: function() {
			this.collection.on("add", this.render, this);
			this.collection.on("reset", this.render, this);
			this.collection.on("remove", this.render, this);
		},
		render: function() {
			var template = this.template({ id: 'assignment-section', collection: this.collection.models });
			this.$el.html(template);
			return this;
		}
	});


}());