window.Observation = {
	Models : {},
	Views  : {},
	Collections : {},
	Helpers : {}
};


Observation.Models.ObservationModel = Backbone.Model.extend({
	defaults : {
		Id : null,
		TeamMember : null,
		TeamMemberId : null,	
		ObservationType : null,
		ObservedEventId: null,
		ObservedEvent : null,
		CompositeScore : null,
		ObservationDate : null,
		AssignmentsGivenId : null,
		AssignmentsGiven : null,
		SuccessPlan : null
	}
});

Observation.Collections.ObservationCollection = Backbone.Collection.extend({
	model : Observation.Models.ObservationModel,
	url : "peoplestorageretrieve"
});


Observation.Views.ObservationView = Coach.Views.CoachView.extend({
	el : '#observation-section',
	initialize : function(options) {
		this.seller = options.seller;
		this.successplan = options.successplan;
		this.render({ id: null });
		this.linkpage = options.obsfield;
	},
	render : function(options) {
		var that = this;
		if(this.collection.size() != 0) {
			var template = Observation.Helpers.Template( { collection : this.collection.models } );
			this.$el.html(template);
		} else {
			this.$el.empty();
		}
	},
	events : {
		'click .team-member-look' : 'showObervation',
		"click .people-select": "rerenderPage"
	},
	showObervation: function(vent) {
		var target = $(vent.currentTarget);
		var teamId = target.attr("data-user");
		var details = Observation.Helpers.Frame({page:this.linkpage, id:teamId});
		$('#observation-header,#observation-section').css('display','none');
		$('#observation-lookup-head').html(details);		
	}
});


Observation.Helpers.Template = function(options) {
	return ALCTemplates.ObservationTemplate({ collection : options.collection });
};

Observation.Helpers.FrameContainer = function() {
	var container = document.createElement('div');
	container.className = 'observation-lookup';
	container.style.width = '100%';
	return container;
};


Observation.Helpers.Frame = function(src) {
	var _cnt = $('.observation-lookup');
	var _if =$('<iframe/>');
	_if.width('100%');
	_if.attr('seamless','');
	_if.attr('id','observation-iframe');
	_if.attr('frameborder','0');
	_if.attr('src', src.page + '?id=' + src.id);
	_if.bind("load", function(vent){ var target = $(vent.currentTarget); target.height(target.contents().height() + 10); });
	return _if;
};