window.LC_App = {
	application_start: function() {
		
	},
	opportunity_section_initialize: function(data) {
		if (data && data instanceof Array) {
			var model = this.PageConfiguration.opportunityPage.call(this);
			var _po = (model) ? model.get('pageOutput') : 10;
			this.OpportunityCollection 		= new Opportunity.Collections.OppReview(data);

			if (_po > this.OpportunityCollection.length) _po =  this.OpportunityCollection.length;
			
			var _nf	= (model) ? model.get('no_few') 	: false;
			var _nm = _po ===  this.OpportunityCollection.length ? false : true;
			
			if(_po == 0 || _po < 10) { _po = 10; _nf = false; _nm = true; }
			
			this.OpportunityGoToListModel 	= new Opportunity.Models.OpportunityGoToList({	link: "", 
																							object_name:"Opportunities", 
																							perPage: 10,
																							no_more: _nm,
																							no_few: _nf, 
																							pageOutput: _po, 
																							size: this.OpportunityCollection.length });
			this.OpportunitySectionView 	= new Opportunity.Views.OppsReview({collection: this.OpportunityCollection});
			return 	{ 
				section  : this.OpportunitySectionView,
				gotoList : new Opportunity.Views.OpportunityGoToList({model: this.OpportunityGoToListModel}),
				po 		 : _po	
			};
		}
	},
	accountplan_section_initialize: function(data) {
		if (data && data instanceof Array) {
			var model = this.PageConfiguration.accountplanPage.call(this);
			var _po = (model) ? model.get('pageOutput') : 10;
			this.AccountPlanCollection 		= new Opportunity.Collections.AccountReview(data);

			if (_po > this.AccountPlanCollection.length) _po =  this.AccountPlanCollection.length;

			var _nf	= (model) ? model.get('no_few') 	: false;
			var _nm = _po ===  this.AccountPlanCollection.length ? false : true;

			if(_po == 0 || _po < 10) { _po = 10; _nf = false; _nm = true; }
			this.AccountPlanGoToListModel 	= new Opportunity.Models.OpportunityGoToList({	link: "", 
																							object_name:"Accounts", 
																							perPage: 10,
																							no_more: _nm,
																							no_few: _nf, 
																							pageOutput: _po, 
																							size: this.AccountPlanCollection.length });
			this.AccountPlanSectionView = new Opportunity.Views.AccountReview({ collection: this.AccountPlanCollection });
			return {
				section  : this.AccountPlanSectionView,
				gotoList : new Opportunity.Views.AccountGoToList({ model: this.AccountPlanGoToListModel }),
				po 		 : _po	
			};
		}
	},
	assignment_section_initialize: function(data) {
		if (data && data instanceof Array) {
			var model = this.PageConfiguration.assignmentPage.call(this);
			var _po = (model) ? model.get('pageOutput') : 10;

			this.AssignmentCollection 		= new Assignment.Collections.AssignCollection(data);

			if (_po > this.AssignmentCollection.length) _po =  this.AssignmentCollection.length;
			var _nf	= (model) ? model.get('no_few') 	: false;
			var _nm = _po ===  this.AssignmentCollection.length ? false : true;
			if(_po == 0 || _po < 10) { _po = 10; _nf = false; _nm = true; }
			this.AssignmentGoToListModel 	= new Opportunity.Models.OpportunityGoToList({	link: "", 
																							object_name:"Assignments", 
																							perPage: 10,
																							no_more: _nm,
																							no_few: _nf,
																							pageOutput: _po, 
																							size: this.AssignmentCollection.length });
			this.AssignmentSectionView 	= new Assignment.Views.AssignmentView({ collection: this.AssignmentCollection  });
			return {
				section  : this.AssignmentSectionView,
				gotoList : new Assignment.Views.AssignmentGoToList({ model: this.AssignmentGoToListModel }),
				po 		 : _po	
			};
		}
	},
	OpportunityCollection 		: null,
	PeopleCollection			: null,
	AccountPlanCollection		: null,
	AssignmentCollection		: null,

	OpportunityGoToListModel 	: null,
	AccountPlanGoToListModel	: null,
	AssignmentGoToListModel		: null,

	OpportunitySectionModel		: null,
	AccountPlanSectionModel		: null,
	AssignmentSectionModel		: null,

	OpportunitySectionView		: null,
	AccountPlanSectionView		: null,
	AssignmentSectionView		: null,

	PageConfiguration 			: {
		opportunityPage: function(){
			return this.OpportunityGoToListModel;
		},
		accountplanPage: function(){
			return this.AccountPlanGoToListModel;
		},
		assignmentPage : function(){
			return this.AssignmentGoToListModel;
		}
	}

};