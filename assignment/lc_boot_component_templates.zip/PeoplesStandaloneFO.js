$(function(){
	window.Coach = {
		Models:{},
		Views:{},
		Collections:{},
		Helpers:{},
		CallBacks: {}
	};

	Coach.Helpers.MaxTime = 2000;
	Coach.Helpers.Timer = null;
	Coach.CallBacks.RerenderOpportunity = null;
	Coach.CallBacks.AssSection = null;
	Coach.CallBacks.ObservationSection = null;

	Coach.Helpers.History = {
		selected_people: [],
		seller_map: {},
		main_seller_id: null
	};

	Coach.Helpers.Template = function(options){
		return ALCTemplates.PeopleTemplateStandaloneFO( {collection: options.list} );
	};

	Coach.Helpers.unFormat = function(param) {
		return parseInt(param.replace(/\D/g, ""));
	};

	Coach.Helpers.Format = function (param) {
		var parts = param.toString().split(".");
		parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
		return parts.join(".");
	};

	Coach.Models.CoachModel = Backbone.Model.extend({
		defaults: {
			Id: null,
			Name: null,
			Annual_Sales: null,
			Sales:null,
			PredictedSales: null,
			Performance: null,
			PredSalesPerformance: null,
			haveBottom: null,
			Treshold: null,
			NumbersObservations: null,
			NumbersAssignments: null
		},
		intitialize: function(){
			
		},
		urlRoot: 'peoplestorageretrieve'
	});

Coach.Views.CoachView = Backbone.View.extend({
		el:'#peopleSection',
		initialize:function(options){
			this.obsfield = options.obsfield;
			this.successplan = options.successplan;
			this.render(options);
		},
		render:function(options) {
			if(options.callbacks) {
				Coach.CallBacks.RerenderOpportunity = options.callbacks.OppSection;
				Coach.CallBacks.AssSection = options.callbacks.AssSection;
				Coach.Helpers.History.main_seller_id = options.id;
			}

			var that = this;
			var coaches = new Coach.Collections.Coaches();
			if(!options.target) {
					coaches.fetch({
						data: {
							id: options.id,
							section : 'peoplesstandalonefo'
						},
						success: function(users){
							if(users.length === 0) {
								$('.people').remove();
							} else {
								var template = Coach.Helpers.Template({ list: users.models, helper: Coach.Helpers });	
								that.$el.html(template);
							}
						}
					});
			} else {
				var collect = new Coach.Collections.Coaches();
				collect.fetch({
					data:{
						id : options.id,
						section : 'peoplesstandalonefo'
					},
					success:function(users){
						var _tmpl = Coach.Helpers.Template({ list: users.models });
						if($.trim(_tmpl).length !== 0) {
							that.$("#user-" + options.id + ' ~ .sub-people-section:first').append(_tmpl);
						} else {
							options.target.removeClass("m-ico-plus");
							options.target.removeClass("m-ico-minus");
						}
					},
					error:function(some){
						
					}
				});
			}
			return this;
		},
		events: {
			"click a.plus":"showList",
			"click .people-select": "rerenderPage"
		},
		showList: function(ev) {
			var target = $(ev.currentTarget);
			var id = target.attr("data-user");	
			var _st = target.attr("data-status");
			var _oc = '';
			if(target.hasClass("m-ico-plus")) {
				target.removeClass("m-ico-plus");
				target.addClass("m-ico-minus");
				_oc = '+';
			} else {
				target.removeClass("m-ico-minus");
				target.addClass("m-ico-plus");
				_oc = '-';
			}
			if(_st === "false") {
				this.render({id: id, target: target});
				target.attr("data-status", "true");
			} else {
				switch (_oc) {
					case '+': this.$("#user-" + id + ' ~ .sub-people-section:first').fadeIn("1000"); break;
					case '-': this.$("#user-" + id + ' ~ .sub-people-section:first').fadeOut("1000"); break;
					default: break;
				}
			}

		},
		rerenderPage: function(vent) {
			var target = $(vent.currentTarget);
			var key = target.attr("data-check");
			var uncheck_flag = false;
			
			if(key in Coach.Helpers.History.selected_people) {
				for(var item_seller in Coach.Helpers.History.seller_map[key]) {
					if(Coach.Helpers.History.seller_map[key].hasOwnProperty(item_seller)) {
						var sub_key = Coach.Helpers.History.seller_map[key][item_seller];
						delete Coach.Helpers.History.selected_people[sub_key];
					}
				}
				
				delete Coach.Helpers.History.selected_people[key];
				uncheck_flag = true;
				var nextUncheck = $('#user-' + key + ' ~ .sub-people-section:first').find("input[type=checkbox]");
				
				_.each(nextUncheck, function(item){
					item.checked = false;
					delete Coach.Helpers.History.selected_people[item.getAttribute("data-check")];
				});
			}
			else {
				Coach.Helpers.History.selected_people[key] = true;
				var nextCheck = $('#user-' + key + ' ~ .sub-people-section:first').find("input[type=checkbox]");
				var subordinates = {};
					subordinates[key] = [];
				Coach.Helpers.History.seller_map = [  ];
				_.each(nextCheck, function(item) {
					item.checked = true;
					Coach.Helpers.History.selected_people[item.getAttribute("data-check")] = true;
					subordinates[key].push(item.getAttribute("data-check"));
				});
				Coach.Helpers.History.seller_map[key] = subordinates[key];
			}

			var that = this;

			if(Coach.Helpers.Timer != null) {
				clearTimeout(Coach.Helpers.Timer);
				Coach.Helpers.Timer = setTimeout(function() { that.startWork.call(that); }, 2000);
			} else {
				Coach.Helpers.Timer = setTimeout(function() { that.startWork.call(that); }, 2000);
			}
		},
		startWork: function() {
			var showCompletedAssignments = $('#toggleAssignments').attr("data-completed");
			if(_.keys(Coach.Helpers.History.selected_people).length > 0) {
				var keyIds = _.keys(Coach.Helpers.History.selected_people);
				var ids = keyIds.join("::");
				ids += '::';
				$('#people-collection').val(ids);
				Coach.CallBacks.RerenderOpportunity(ids ,null,null);
				Coach.CallBacks.AssSection(ids ,null,showCompletedAssignments);

				if(Coach.Helpers.Timer != null) {
					clearTimeout(Coach.Helpers.Timer);Coach.Helpers.Timer = null;
					return;
				}
				Coach.Helpers.Timer = setTimeout(this.startWork, 2000);
				
			} else {
				Coach.CallBacks.RerenderOpportunity(Coach.Helpers.History.main_seller_id, null, null);
				Coach.CallBacks.AssSection(Coach.Helpers.History.main_seller_id, null, showCompletedAssignments);
				$('#people-collection').val('');
			}
		}
	});

	Coach.Collections.Coaches = Backbone.Collection.extend({
		url: 'peoplestorageretrieve',
		model: Coach.Models.CoachModel
	});



}());