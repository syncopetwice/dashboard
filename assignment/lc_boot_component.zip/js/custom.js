$(document).ready(function() {
	$.extend($.ui.dialog.prototype.options, {modal: true});
	$('select').addClass('chzn-select');
    $('.chzn-select').change(function() {
        
        setTimeout(function(){$('.chzn-select').chosen();}, 25);
        setTimeout(function(){$('.chzn-select').chosen();}, 50);
        setTimeout(function(){$('.chzn-select').chosen();}, 75);
        setTimeout(function(){$('.chzn-select').chosen();}, 100);
        setTimeout(function(){$('.chzn-select').chosen();}, 125);
        setTimeout(function(){$('.chzn-select').chosen();}, 150);
        setTimeout(function(){$('.chzn-select').chosen();}, 175);
        setTimeout(function(){$('.chzn-select').chosen();}, 200);
        setTimeout(function(){$('.chzn-select').chosen();}, 225);
        setTimeout(function(){$('.chzn-select').chosen();}, 250);
        setTimeout(function(){$('.chzn-select').chosen();}, 275);
    	setTimeout(function(){$('.chzn-select').chosen();}, 300);
    	setTimeout(function(){$('.chzn-select').chosen();}, 325);
    	setTimeout(function(){$('.chzn-select').chosen();}, 350);
    	setTimeout(function(){$('.chzn-select').chosen();}, 375);
    	setTimeout(function(){$('.chzn-select').chosen();}, 400);
    	setTimeout(function(){$('.chzn-select').chosen();}, 425);
    	setTimeout(function(){$('.chzn-select').chosen();}, 450);
    	setTimeout(function(){$('.chzn-select').chosen();}, 475);
    	setTimeout(function(){$('.chzn-select').chosen();}, 500);
    	setTimeout(function(){$('.chzn-select').chosen();}, 525);
    	setTimeout(function(){$('.chzn-select').chosen();}, 550);
    	setTimeout(function(){$('.chzn-select').chosen();}, 575);
    	setTimeout(function(){$('.chzn-select').chosen();}, 600);
    	setTimeout(function(){$('.chzn-select').chosen();}, 625);
        setTimeout(function(){$('.chzn-select').chosen();}, 650);
        setTimeout(function(){$('.chzn-select').chosen();}, 675);
        setTimeout(function(){$('.chzn-select').chosen();}, 700);
        setTimeout(function(){$('.chzn-select').chosen();}, 725);
        setTimeout(function(){$('.chzn-select').chosen();}, 750);
        setTimeout(function(){$('.chzn-select').chosen();}, 775);
        setTimeout(function(){$('.chzn-select').chosen();}, 800);
        setTimeout(function(){$('.chzn-select').chosen();}, 825);
        setTimeout(function(){$('.chzn-select').chosen();}, 850);
        setTimeout(function(){$('.chzn-select').chosen();}, 875);
        setTimeout(function(){$('.chzn-select').chosen();}, 900);
        setTimeout(function(){$('.chzn-select').chosen();}, 925);
        setTimeout(function(){$('.chzn-select').chosen();}, 950);
        setTimeout(function(){$('.chzn-select').chosen();}, 975);
        setTimeout(function(){$('.chzn-select').chosen();}, 1000);
        setTimeout(function(){$('.chzn-select').chosen();}, 1025);
        setTimeout(function(){$('.chzn-select').chosen();}, 1050);
        setTimeout(function(){$('.chzn-select').chosen();}, 1075);
        setTimeout(function(){$('.chzn-select').chosen();}, 1100);
        setTimeout(function(){$('.chzn-select').chosen();}, 1200);
        setTimeout(function(){$('.chzn-select').chosen();}, 1300);
        setTimeout(function(){$('.chzn-select').chosen();}, 1400);
        setTimeout(function(){$('.chzn-select').chosen();}, 1500);
        setTimeout(function(){$('.chzn-select').chosen();}, 1600);
        setTimeout(function(){$('.chzn-select').chosen();}, 1700);
        setTimeout(function(){$('.chzn-select').chosen();}, 1800);
    });
    $('.datePicker select').removeClass('chzn-select');
    $('.datePicker select').removeClass('chzn-done');
    $('.chzn-select').chosen();

	
	var monthSel = $('.datePicker select#calMonthPicker');
	$(monthSel).hide();
	var monthSelVal = $(".datePicker select#calMonthPicker option:selected").text();
	var yearSelVal = $('.datePicker select#calYearPicker option:selected').text();
	$(monthSel).parent().prepend('<div class="Month-label">'+monthSelVal + ' ' + yearSelVal+'</div>');
	
	
	$('.dateInput.dateOnlyInput input').focus(function(){
		var monthSel = $('.datePicker select#calMonthPicker');
		$(monthSel).hide();
		var monthSelVal = $(".datePicker select#calMonthPicker option:selected").text();
		var yearSelVal = $('.datePicker select#calYearPicker option:selected').text();
		$('.Month-label').text(monthSelVal + ' ' + yearSelVal);
	});
	

    //$('.Month-label').text(monthSelVal + ' ' + yearSelVal);
    $('.calRight').click(function(){
        var monthSelValr = $('.datePicker select#calMonthPicker option:selected').text();
        var yearSelValr = $('.datePicker select#calYearPicker option:selected').text();
        $('.Month-label').text(monthSelValr + ' ' + yearSelValr);
    });
    $('.calLeft').click(function(){
        var monthSelVall = $('.datePicker select#calMonthPicker option:selected').text();
        var yearSelVall = $('.datePicker select#calYearPicker option:selected').text();
        $('.Month-label').text(monthSelVall + ' ' + yearSelVall);
    });
	
	$(".dayOfWeek").text(function(index, text) {
        return text.substr(0, 2);
    });

    
});